update f
set FileSubmissionDescription = 'SCHOOL CCD SCHOOL'
from app.FileSubmissions f
	inner join app.GenerateReports r
		on f.GenerateReportId = r.GenerateReportId
where f.submissionyear = 2026
and r.reportcode = '129'

update f
set FileSubmissionDescription = 'SCHOOL FREE AND REDUCED PRICE LUNCH'
from app.FileSubmissions f
	inner join app.GenerateReports r
		on f.GenerateReportId = r.GenerateReportId
where f.submissionyear = 2025
and r.reportcode = '033'
